<?php

// getting header
get_header2($routerController);

// body for invoice
get_body2($routerController);

// footer
get_footer2($routerController);

