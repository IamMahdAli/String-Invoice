<?php

// getting header
get_header2($routerController);

// body for invoice
get_body('is_new_invoice') ;

// footer

get_footer('is_new_invoice');
 