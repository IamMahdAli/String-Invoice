<?php
// getting header
get_print_header($routerController);

// body for invoice
get_body2($routerController);

// footer
get_print_footer($routerController, $routerMethod, $routerParams);
