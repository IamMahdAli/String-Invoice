<?php

// getting header
get_header2($routerController);

// body for string new records
get_body('is_string_new_record');

// footer
get_footer('is_string_new_record');


