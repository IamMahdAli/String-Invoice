
</section>

<footer>
<script src="<?php echo JS ?>jquery.js"></script>
    <?php
footerJsFile('hamberger-active');

switch ($routerController) {
    case 'thread-records';

        jsFile('datatables.min');
    break;

    case 'print-invoice';
        jsFile('jquery.printarea');

    break;
    default;
}

?>
<script >
<?php if (isset($routerMethod)):  ?>
var routerMethod = "<?php echo $routerMethod?>";

<?php endif; ?>

<?php if(isset($routerParams)): ?>
var routerParams  = "<?php echo $routerParams?>";
<?php endif; ?>
<?php

switch ($routerController){

    case ('edit-record');

?>
var urlGetThread = "<?php echo MODELS . 'model_get_thread.php' ?>";
var updateUrl = "<?php echo MODELS . 'model_update_thread.php' ?>";
<?php
    break;

    case ('get-invoice');

?>
<?php

    break;

    case 'print-invoice';
?>
        var invoiceToPrint = <?php echo $routerParams ?>;
    var urlGetInvoice = "<?php echo MODELS . 'model_get_invoice.php' ?>";
    var urlGetInvoiceRows = "<?php echo MODELS . 'model_get_invoice_rows.php' ?>";

<?php

break;

default;
}
?>

</script>

<?php

footerJsFile($routerController);
footerJsFile('hamberger-active');


?>
</footer>
</body>


</html>