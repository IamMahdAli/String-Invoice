<?php

?>
<!--        side nav-->

<main style="min-height: 60vh " class="container column  box is-9 is-full-touch ">


    <section class="section   ">
        <!--                main body-->
        <header>
            <h2 class="title is-4 marginBottom">
                Thread Record Book
            </h2>
        </header>

        <div id="status" class="has-background-primary has-text-white"></div>
<!-- header of page -->


        <!--            start: status div          -->

        <div id="tableStatus" class="has-background-primary display nowrap"" >  </div>

        <!--           end: status div             -->

                <div class="column ">


                    <div class="container ">
                        <form action="">

                        <div class="column">
                            <div class="columns">


<!-- options to delete-->
                                <div>

                                    <div>
                                        <input onclick="return confirm('Are you sure, you wants to delete selected items?')" type="button" name="deleteAll" id="deleteAll" class="is-danger is-radiusless button" value="Delete">
                                    </div>
<!--  new record button -->
                                </div>

                                <div class="container marginBottom has-text-right">
                                    <a class="button is-radiusless is-4 is-info " href="new-record">Add New Record</a>
                                </div>

                            </div>
                        </div>

                            <div class="columns is-centered ">

                                <table style="border: 1px solid #dbdbdb" class="table" id="threadRecordsTable">
                                    <thead>
                                    <tr>
                                        <th><abbr title="Select to delete all records on this page"> <input type="checkbox" name="threadDeleteAll" class="threadDeleteAll" ></abbr></th>
                                        <th><abbr title="Time when respective record was modified last time">Last Modified</abbr></th>
                                        <th><abbr title="Thread amount per pack">Per Pack</abbr></th>
                                        <th><abbr title="Numberof thread in stock">In Stock</abbr></th>
                                        <th><abbr title="Comment of the thread">Thread Comment</abbr></th>
                                        <th><abbr title="Number of thread Records">Thread No</abbr></th>
                                        <th><abbr title="Delete or Edit">Action</abbr></th>

                                    </tr>
                                    </thead>
                                    <tfoot>
                                    <tr>
                                        <th><abbr title="Select to delete all records on this page"> <input type="checkbox" name="threadDeleteAll" class="threadDeleteAll" ></abbr></th>
                                        <th><abbr title="Time when respective record was modified last time">Last Modified</abbr></th>
                                        <th><abbr title="Thread amount per pack">Per Pack</abbr></th>
                                        <th><abbr title="Numberof thread in stock">In Stock</abbr></th>
                                        <th><abbr title="Comment of the thread">Thread Comment</abbr></th>
                                        <th><abbr title="Number of thread Records">Thread No</abbr></th>
                                        <th><abbr title="Delete or Edit">Action</abbr></th>

                                    </tr>
                                    </tfoot>
                                </table>

                            </div>
                        </form>

                    </div>

                    <?php

                    ?>
                </div>


<!--        main content area-->

        <!--                main body-->


    </section>
</main>


