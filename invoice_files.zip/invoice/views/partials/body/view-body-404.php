

<!--        side nav-->
<!--<main class="container column  box is-9 hero is-fullheight">-->

<!--<main class="container column  box is-9 hero is-halfheight ">-->
<main style="min-height: 60vh " class="container column  box is-9  is-full-touch ">
    <section class="section   ">
        <!--                main body-->
        <header>
            <h1 class="title is-4  ">OOPS! </h1>

        </header>
        
        <p class="section">Something Went wrong :( </p>
        


        <!--                main body-->


    </section>
</main>

