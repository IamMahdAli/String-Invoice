

<!--        side nav-->
<!--<main class="container column  box is-9 hero is-fullheight">-->

<!--<main class="container column  box is-9 hero is-halfheight ">-->


<main style="min-height: 60vh " class="container column  box is-9 is-full-touch ">
    <section class="section   ">
        <!--                main body-->

        <h2 class="title is-4 marginBottom">
            Welcome To Invoice Software
        </h2>

        <div class="columns">
            <div class="column">
                <div class="columns">

                    <div class="column"><strong>No Of Total Invoice: </strong></div>

                    <div class="column"><span id="invoiceTotalNo"></span></div>

                </div>
                <hr>

                <div class="columns">

                    <div class="column"><a target="_blank" href="index.php/all-invoice" class="button  is-primary is-radiusless ">All Invoice</a></div>
                    <div class="column"><a target="_blank" href="index.php/new-invoice" class="button  is-info  is-radiusless ">New Invoice</a></div>

                </div>
            </div>

            <div class="column">
                <div class="columns">

                    <div class="column"><strong>Total Thread Records: </strong></div>

                    <div class="column"><span id="threadTotalNo"></span></div>

                </div>

                <hr>

                <div class="columns">

                    <div class="column"><a target="_blank" href="index.php/thread-records" class="button  is-primary is-radiusless ">All Threads</a></div>
                    <div class="column"><a target="_blank" href="index.php/new-record" class="button  is-info  is-radiusless ">New Thread</a></div>

                </div>
            </div>

        </div>
      <!--                main body-->


    </section>
</main>

