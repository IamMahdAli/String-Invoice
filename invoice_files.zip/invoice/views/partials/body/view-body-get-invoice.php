


<!--        side nav-->
<main  style="min-height: 60vh " class="container column  box is-9 is-full-touch ">
    <section class="section   ">
        <!--                main body-->
        <header style=" " class="marginBottom">
            <h1 class="title is-4  ">My Invoice</h1>

        </header>

        <div class="columns is-centered">

            <div>
                <strong style="font-size: 90px" class="is-family-monospace" >ASF</strong>

            </div>
            <div style="margin-top: 40px" class="">
                <div class="is-family-monospace">
                    Sewing

                </div>
                <div>
                    Thread
                </div>
            </div>

        </div>

        <div class="container ">





            <div class="level">

                <div class="  level-item  ">
                    <label for="date">Date: &nbsp; </label>
                    <input style="width: 120px" type="text" name="invoiceCreatedDate" value="" class="" disabled  id="invoiceCreatedDate">

                </div>




                <div class="  level-item    ">
                    <label for="invoiceNo">Name: &nbsp; </label>
                    <input style="width: 120px" type="text" name="invoiceName" value="" class="" disabled  id="invoiceName">

                </div>

                <div class="  level-item  ">
                    <label for="date">Invoice No: &nbsp; </label>
                    <input style="width: 120px" type="text" name="invoiceNo" value="" class="" disabled  id="invoiceNo">
                    <input style="width: 120px" type="text" name="invoiceNoToDelete" value="" class="" hidden  id="invoiceNoToDelete">



                </div>
                <!--header of invoice-->
            </div>



            <!-- invoice head-->
            <?php $threadNo = 1;
            $invoiceDetailName = 'invoiceDetail'. $threadNo ;
            $invoiceNumberName = 'invoiceThread'. $threadNo ;
            $invoiceQuantityName = 'invouceQuantity'. $threadNo;
            $invoiceTotal  = 'invoiceTotal'. $threadNo;
            $invoicePerPack = 'invoicePerPack'. $threadNo;
            $packQualtity = 10;
            $perPack = 123;
            $packTotal = $packQualtity * $perPack ;

            $rowNumber = 0;


            ?>

            <div class="columns is-centered">
                <form action="" id="invoiceData">

                    <table class="   is-fullwidth  table is-bordered ">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th><abbr title="Detail about order">Detail( Max 100 Ch )</abbr></th>
                            <th><abbr title="No of thread to add detail about">Thread No</abbr></th>
                            <th><abbr title="Number of packs bought">Quantity</abbr></th>
                            <th><abbr title="Price Per Pack ( 1 pack = 12 units )">Per Pack</abbr></th>
                            <th><abbr title="Total ammount">Total</abbr></th>

                        </tr>
                        </thead>
                        <!--                            header of table -->
                        <tfoot>
                        <tr>
                            <th>No</th>
                            <th><abbr title="Detail about order">Detail( Max 100 Ch )</abbr></th>
                            <th><abbr title="No of thread to add detail about">Thread No</abbr></th>
                            <th><abbr title="Number of packs bought">Quantity</abbr></th>
                            <th><abbr title="Price Per Pack ( 1 pack = 12 units )">Per Pack</abbr></th>
                            <th><abbr title="Total ammount">Total</abbr></th>


                        </tr>
                        </tfoot>
                        <!--                            footer of table -->

                        <tbody id="tableBody">



                        </tbody>
                        <!--                            body of table -->
                    </table>
                </form>
            </div>

            <div>


                <div class="column">
                    <div class="level">


                        <div class="level-left ">

                        </div>

                    </div>
                </div>

                <label class="marginBottom" style="padding-left: 15px"  for="descriptionForuser">Anything you wants to add for your own self</label>

                <div class="column">
                    <textarea name="descriptionForuser" id="descriptionForuser" cols="30" rows="3" placeholder="Description for user"></textarea>
                </div>

                <div class="columns ">
                    <div class="column is-4">
                        <table class="table">
                            <thead>

                            </thead>
                            <tfoot>

                            </tfoot>
                            <tbody>
                            <tr>
                                <th>Invoice Subtotal</th>
                                <td><input type="text" name="invoiceSubTotal" id="invoiceSubTotal" class="input is-primary"></td>
                            </tr>
                            <tr>
                                <th> Invoice Total</th>
                                <td><input type="text" name="invoiceTotal" id="invoiceTotal" class="input is-primary"></td>

                            </tr>

                            </tbody>
                        </table>
                    </div>


                </div>

            </div>


            <div class="column">

                <?php
                $url = isset($_SERVER['PATH_INFO']) ? explode('/', ltrim($_SERVER['PATH_INFO'], '/')) : [];

                $invoiceNo = $url[2]
                ?>
                <a target="_blank" href="../../print-invoice/invoice-no/<?php echo $invoiceNo ?>" class="button is-radiusless is-primary " id="printInvoice" > Print Invoice </a>

            </div>
            </form>
        </div>


        <!--                main body-->

    </section>
</main>


