

<!--        side nav-->
<main id="printBody"  style="min-height: 60vh " class="container column   box is-9 is-full-touch ">
    <section class="section   ">
        <!--                main body-->


        <div  style="margin-top: -64px; margin-bottom: -25px;" class="columns is-centered">

            <div>
                <strong style="font-size: 90px" class="is-family-monospace" >ASF</strong>

            </div>
            <div style="margin-top: 40px" class="">
                <div class="is-family-monospace">
                    Sewing

                </div>
                <div>
                    Thread
                </div>

            </div>

        </div>
        <hr style="border: .1px solid black" size="13px" noshade color="#6f2f2f">


        <!--// here-->
        <div style="padding: 10px" class="columns">

            <div class="   column has-text-centered ">
                <label for="clientName" cla>Client Name &nbsp; </label> <br>
                <p ><strong id="clientName"></strong></p>

            </div>




            <div class="   column has-text-centered ">


                <div class="">

                <label for="invoiceNo">Invoice Number &nbsp; </label>
                <p ><strong id="invoiceNo" ></strong></p>
                </div>

            </div>


            <div class="  column has-text-centered ">


                <div class="">

                    <label for="invoiceDate">Date Of Issue &nbsp; </label>
                    <p ><strong id="invoicedate" ></strong></p>
                </div>

            </div>

            <div class="  column has-text-centered ">


                <div class="">

                    <label for="invoiceNo">Total &nbsp; </label>
                    <p  >Rs<strong id="invoiceTotal" style="font-size: 40px"></strong></p>
                </div>

            </div>
            <!--header of invoice-->

        </div>

        <div style=" " ><hr style="border: .1px solid black;     margin-bottom: 48px;
    margin-top: -11px;" size="13px" noshade color="#6f2f2f"></div>

        <div class="container ">

            <!-- invoice head-->
            <?php $threadNo = 1;
            $invoiceDetailName = 'invoiceDetail'. $threadNo ;
            $invoiceNumberName = 'invoiceThread'. $threadNo ;
            $invoiceQuantityName = 'invouceQuantity'. $threadNo;
            $invoiceTotal  = 'invoiceTotal'. $threadNo;
            $invoicePerPack = 'invoicePerPack'. $threadNo;
            $packQualtity = 10;
            $perPack = 123;
            $packTotal = $packQualtity * $perPack ;

            $rowNumber = 0;


            ?>


            <div class="columns is-centered">
                <form action="" id="invoiceData">

                   <table class="   is-fullwidth  table is-bordered ">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th> Info</th>
                            <th><abbr title="No of thread to add detail about">Thread Number</abbr></th>
                            <th>Quantity</th>
                            <th>Per Pack</th>
                            <th>Total</th>

                        </tr>
                        </thead>
                        <!--                            header of table -->
                        <tfoot>
                        <tr>

                        </tr>
                        </tfoot>
                        <!--                            footer of table -->

                        <tbody id="tableBody">



                        </tbody>
                        <!--                            body of table -->
                    </table>
                </form>
            </div>



            </form>
        </div>


        <div> <hr style="border: .1px solid black;     margin-top: 47px;
    margin-bottom: -33px;" size="13px" noshade color="#6f2f2f">
        </div>

        <div style="margin-top: 40px" class="columns ">
            
            <div class="column is-4">
                <table class="table">
                    <thead>

                    </thead>
                    <tfoot>

                    </tfoot>
                    <tbody>
                    <tr>
                        <th>Invoice Subtotal</th>
                        <td> <p><strong >Rs<span id="subTotal" ></span></strong></p></td>
                    </tr>
                    <tr>
                        <th> Invoice Total</th>
                        <td> <p><strong >Rs<span id="total" ></span></strong></p> </td>

                    </tr>

                    </tbody>
                </table>
            </div>

    
        </div>
        <!--                main body-->
        <div class="columns">

    </section>
    <div class="columns ">
        <div class="column has-text-centered ">Invoice and Copyright © 2019 by DataCoups.com. All Rights Reserved.</div>
    </div>
</main>


