


<!--        side nav-->
        <main  style="min-height: 60vh " class="container column  box is-9 is-full-touch ">
            <section class="section   ">
<!--                main body-->
 <header style=" " class="marginBottom">
    <h1 class="title is-4  ">Add New Invoice</h1>

</header>

                <div class="columns is-centered">

                    <div>
                        <strong style="font-size: 90px" class="is-family-monospace" >ASF</strong>

                    </div>
                    <div style="margin-top: 40px" class="">
                        <div class="is-family-monospace">
                            Sewing

                        </div>
                        <div>
                            Thread
                        </div>
                    </div>

                </div>

                <div class="container ">


                    <div class="columns ">

                        <div class="marginRight ">
                            <form action="" id="formNoOfRows" name="formNoOfRows">
                                <input type="number" name="noOfRows" id="noOfRows" class="input is-primary">
                            </form>

                        </div>

                        <div>
                            <button type="submit" value="createRows" name="createRows" class="button is-info is-radiusless" id="createRows" form="formNoOfRows" >Create Rows</button>
                            <!--                                <button value="createRows" name="createRows" class="button is-info is-radiusless" id="createRows" >Create Rows</button>-->
                        </div>
                    </div>

<!--                    <form action="" id="invoiceHead" >-->

                    <div class="level">

     <div class="  level-item  ">
         <label for="date">Date: &nbsp; </label>

         <input   date-color="info"  id="datepickerDemo2" class="input" type="date"  name="invoiceDate">
<!--         <input type="date" data-display-mode="inline" data-is-range="true" data-close-on-select="false" id="my-element">-->

     </div>



                        <div class="  level-item    ">
         <label for="invoiceNo">Name: &nbsp; </label>
         <input type="text" name="invoiceName" class="invoiceName"  id="invoiceNamenn" value="">
     </div>
                        <!--header of invoice-->
 </div>



                        <!-- invoice head-->
                        <?php $threadNo = 1;
                        $invoiceDetailName = 'invoiceDetail'. $threadNo ;
                        $invoiceNumberName = 'invoiceThread'. $threadNo ;
                        $invoiceQuantityName = 'invouceQuantity'. $threadNo;
                        $invoiceTotal  = 'invoiceTotal'. $threadNo;
                        $invoicePerPack = 'invoicePerPack'. $threadNo;
                        $packQualtity = 10;
                        $perPack = 123;
                        $packTotal = $packQualtity * $perPack ;

                        $rowNumber = 0;


                        ?>
                        <div id="parentStatus" class="has-text-white has-background-primary columns marginBottom ">
                            <div class="has-text-white is-primary "><strong class="has-text-white subtitle ">Status:</strong></div>
                            <div id="status">
                                &nbsp;&nbsp; First add rows and then thread no
                            </div>
                        </div>
                        <div class="columns is-centered">
                            <form action="" id="invoiceData">

                            <table class="   is-fullwidth  table is-bordered ">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th><abbr title="Detail about order">Detail( Max 100 Ch )</abbr></th>
                                    <th><abbr title="No of thread to add detail about">Thread No</abbr></th>
                                    <th><abbr title="Number of packs bought">Quantity</abbr></th>
                                    <th><abbr title="Price Per Pack ( 1 pack = 12 units )">Per Pack</abbr></th>
                                    <th><abbr title="Total ammount">Total</abbr></th>
                                    <th><abbr title="Delete All Rows">
                                            Delete
                                        </abbr></th>
                                </tr>
                                </thead>
                                <!--                            header of table -->
                                <tfoot>
                                <tr>
                                    <th>No</th>
                                    <th><abbr title="Detail about order">Detail( Max 100 Ch )</abbr></th>
                                    <th><abbr title="No of thread to add detail about">Thread No</abbr></th>
                                    <th><abbr title="Number of packs bought">Quantity</abbr></th>
                                    <th><abbr title="Price Per Pack ( 1 pack = 12 units )">Per Pack</abbr></th>
                                    <th><abbr title="Total ammount">Total</abbr></th>
                                    <th><abbr title="Delete All Rows">
                                            Delete
                                        </abbr></th>

                                </tr>
                                </tfoot>
                                <!--                            footer of table -->

                                <tbody id="tableBody">



                                </tbody>
                                <!--                            body of table -->
                            </table>
                    </form>
                        </div>

                        <div>


           <div class="column">
               <div class="level">


                   <div class="level-left ">


                   </div>


                   <div class="level-right">    

                       <div>
                           <button id="btnCalTotal" class="button  is-info is-radiusless marginRight">
                               Calculate Total
                           </button>
                           

                           <button id="btnRemoveRow" class="button  is-danger is-radiusless">
                               Delete Row
                           </button>


                       </div>
                   </div>
               </div>
           </div>
                            <label class="marginBottom" style="padding-left: 15px"  for="descriptionForuser">Anything you wants to add for your own self</label>

                            <div class="column">
                               <textarea name="descriptionForuser" id="descriptionForuser" cols="30" rows="3" placeholder="Description for user"></textarea>
                            </div>

                            <div class="columns ">
                                <div class="column is-4">
                                    <table class="table">
                                        <thead>

                                        </thead>
                                        <tfoot>

                                        </tfoot>
                                        <tbody>
                                        <tr>
                                            <th>Invoice Subtotal</th>
                                            <td><input type="text" name="invoiceSubTotal" id="invoiceSubTotal" class="input is-primary"></td>
                                        </tr>
                                        <tr>
                                            <th> Invoice Total</th>
                                            <td><input type="text" name="invoiceTotal" id="invoiceTotal" class="input is-primary"></td>

                                        </tr>

                                        </tbody>
                                    </table>
                                </div>


                            </div>

           </div>


                        <div class="column">
                            <button class="button is-radiusless is-info " id="submitInvoice">New Invoice</button>

                        </div>
                    </form>
                </div>


                <!--                main body-->

            </section>
        </main>


