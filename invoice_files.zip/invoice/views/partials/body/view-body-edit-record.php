

<!--        side nav-->
<!--<main class="container column  box is-9 hero is-fullheight">-->

<!--<main class="container column  box is-9 hero is-halfheight ">-->
<main style="min-height: 60vh " class="container column  box is-9 is-full-touch ">


    <section class="section   ">
        <!--                main body-->
        <header>
            <h2 class="title is-4 marginBottom">
                Edit Thread
            </h2>
        </header>
<!-- header of page -->

        <div class=" ">

            <div class="column is-centered">

                <div class="column">
                    <div id="status" class="has-background-primary has-text-white">

                    </div>
                    <table class="table  ">
                        <thead>
                        <tr>
                            <th><abbr title="Anything else you would like to add?">Comment( Max 100 Ch )</abbr></th>
                            <th><abbr title="What is the cost of one pack?">Per Pack</abbr></th>
                            <th><abbr title="How much thread in stock you have?">In Stock</abbr></th>
                            <th><abbr title="What is number of thread?">Thread No</abbr></th>
                        </tr>
                        </thead>
                        <!--                            header of table -->

                        <tbody id="tableBody">
                        <form action="" id="formUpdateRecord"  >
                            <tr>

                                <td>
                                    <input type="text" name="threadComment" id="threadComment" placeholder="E.g Thread Color is XXXX" class="input is-primary" maxlength="100">
                                </td>
                                <td>
                                    <input type="number"  name="threadPerPack" id="threadPerPack" placeholder="E.g 130" class="input is-primary threadNoFix threadNoWidth">
                                </td>
                                <td>
                                    <input type="number"  class="input is-primary threadNoWidth threadNoFix"  placeholder="E.g 100" id="threadInStock" name="threadInStock">
                                </td>

                                <td>
                                    <input type="number" id="threadNumber" name="threadNumber" placeholder="E.g 345" class="input is-primary threadNoFix threadNoWidth">
                                </td>
                            </tr>







                        </tbody>
                        <!--                            body of table -->
                    </table>
                </div>

                <div class="column">
                    <input type="submit"name="threadupdate" id="threadupdate" value="Update Record" class="button is-radiusless is-info ">

                </div>
                </form>
            </div>


        </div>
<!--        main content area-->

        <!--                main body-->

        <div id="error"></div>


    </section>
</main>


