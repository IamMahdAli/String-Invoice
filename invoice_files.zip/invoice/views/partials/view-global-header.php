<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

<!--    <link rel="stylesheet" href="--><?php //echo CSS ?><!--mystyles.css">-->
    <link rel="stylesheet" href="<?php echo CSS ?>mystyles.css">

    <link rel="stylesheet" href="<?php echo CSS ?>custom.css">
    <link rel="stylesheet" href="<?php echo CSS ?>../fonts/css/all.min.css">

    <?php $currentHeader = $headerFor; ?>

<!--    checking which page is being requested and then adding appropriate title -->
    <?php
    getHead($currentHeader);
    ?>
</head>

<body  class="">
<div id="app">


    <nav class="navbar has-background-grey-darker has-shadow box " role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
            <a class="navbar-item has-text-white " href="#">
               Logo
            </a>

            <a id="navBurger" role="button" class="navbar-burger has-text-white     " aria-label="menu" aria-expanded="false" data-target="upperNav">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
            </a>
        </div>

        <div id="upperNav"  class="navbar-menu has-background-grey-darker ">
            <div class="navbar-start is-hidden-desktop  ">

                <a class="navbar-item has-text-white">
                    <span class="icon"><i class="fa fa-home"></i></span> &nbsp; Home
                </a>

                <a class="navbar-item has-text-white">
                    <span class="icon"><i class="fas fa-book-open"></i></span> &nbsp; View All

                </a>
                <a class="navbar-item has-text-white">
                    <span class="icon"><i class="fa fa-table"></i></span> &nbsp; New Invoice

                </a>
                <a class="navbar-item has-text-white">
                    <span class="icon"><i class="fa fa-info"></i></span> &nbsp; About

                </a>


            </div>

            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="buttons">
                        <a  href="#" class="button is-radiusless is-primary">
                            <strong>Sign up</strong>
                            <span class="icon"><i class="fa fa-user"></i></span>

                        </a>
                        <a href="#" class="button is-radiusless is-info ">
                            <strong>Log in</strong>
                            <span class="icon "><i class="fas fa-sign-out-alt"></i></span>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
<!--     uper nav -->


    <section    class="main-content columns is-fullheight">

        <!--        side nav-->
        <aside class="column is-2 is-narrow-mobile is-fullheight section is-hidden-touch box has-background-grey-darker ">

            <div style="margin-top: 10px;   class="box ">






            <ul   class="menu-list  ">
                <li>
                    <a href="http://localhost/invoice/public_html/index.php" class="navbar-item has-text-white   ">
                        <span class="icon"><i class="fa fa-home"></i></span> &nbsp; Home
                    </a>
                </li>
                <li>

                    <a  href="http://localhost/invoice/public_html/index.php/all-invoice" class="navbar-item has-text-white">
                        <span class="icon"><i class="fas fa-book-open"></i></span> &nbsp; View All Invoice

                    </a>

                </li>
                <li>
                    <a href="http://localhost/invoice/public_html/index.php/new-invoice" class="navbar-item has-text-white">
                        <span class="icon"><i class="fas fa-file-invoice"></i></span>    &nbsp; New Invoice

                    </a>
                </li>

                <li>
                    <a href="http://localhost/invoice/public_html/index.php/thread-records" class="navbar-item has-text-white">
                        <span class="icon"><i class="fas fa-clipboard"></i></i></span> &nbsp; Thread Records

                    </a>
                </li>


                <li>
                    <a href="http://localhost/invoice/public_html/index.php/new-record" class="navbar-item has-text-white">
                        <span class="icon"><i class="fas fa-file"></i></span> &nbsp; New Thread

                    </a>
                </li>


            </ul>


</div>
</aside>
<!--        side nav-->