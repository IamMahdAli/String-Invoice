
</section>

<footer class="footer has-background-grey-darker ">
    <div class="container">
        <div class="content has-text-centered">
            <p class="has-text-white">Copyright © 2019 Afraz Ahmad. All Rights Reserved.</p>
        </div>
    </div>
</footer>
<!-- footer -->
<script src="<?php echo JS ?>jquery.js"></script>


<?php
footerJsFile('hamberger-active');

switch ($routerController) {
    case 'thread-records';

        jsFile('datatables.min');
    break;
    case 'all-invoice';

        jsFile('datatables.min');

        ?>
        <script>
            var deleteInvoice = "<?php echo MODELS . 'model_delete_invoice.php' ?>";
        </script>
        <?php
        break;

    default;
}

?>
<script>
    var deleteUrl = "<?php echo MODELS . 'model_delete_record.php' ?>";
    var deleteMultiple = "<?php echo MODELS . 'model_delete_multiples.php' ?>";

</script>

<?php

footerJsFile($routerController);



?>
</body>


</html>