<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

<!--    <link rel="stylesheet" href="--><?php //echo CSS ?><!--mystyles.css">-->
    <link rel="stylesheet" href="<?php echo CSS ?>mystyles.css">

    <link rel="stylesheet" href="<?php echo CSS ?>custom.css">
    <link rel="stylesheet" href="<?php echo CSS ?>../fonts/css/all.min.css">

    <?php


    switch ($routerController) {

        case 'thread-records';

            getCss('datatables.min');
            break;

        case 'new-invoice';

        getCss('bulma-calendar.min');
        break;

        case 'all-invoice';

            getCss('datatables.min');
            break;


        default;
    }

    ?>

            <title><?php echo $title ?></title>


</head>

<body  class="">

</aside>
<!--        side nav-->