
</section>

<footer class="footer has-background-grey-darker ">
    <div class="container">
        <div class="content has-text-centered">
            <p class="has-text-white">Copyright © 2019 Afraz Ahmad. All Rights Reserved.</p>
        </div>
    </div>
</footer>
<!-- footer -->
<script src="<?php echo JS ?>jquery.js"></script>

<!-- checking for which footer is being called -->
<?php $whichFooter = $footerFor; ?>

<?php
switch ($whichFooter) {

    case('is_new_invoice');

        ?>

        <script src="<?php echo JS ?>bulma-calendar.min.js"></script>
        <script>
            var urlFetch = "<?php echo MODELS . 'model_new_invoice.php'?>";
            var createInvoice = "<?php echo MODELS . 'model_create_invoice.php'?>";
            var createInvoiceRows = "<?php echo MODELS . 'model_create_invoice_rows.php'?>";
        </script>

        <?php
        footerJsFile('new-invoice');
        ?>
    <?php

        break;
//  if footer is being requested for new invoice

    case ('is_index');

        ?>
        <script>
            var urlGetRowNo = "<?php echo MODELS . 'model_all_rows.php' ?>";
        </script>
        <?php
        footerJsFile('home');

        break;

    case ('is_home');


         break;
    //      if footer is being requested for home page

    case ('view-body-string-inventory');

        break;

     case ('is_string_new_record');

        ?>

         <script src="<?php echo FOOTERJS ?>js-new-record.js"></script>

         <?php

        break;



    default;

}
?>

<?php
footerJsFile('hamberger-active');

?>


</body>


</html>