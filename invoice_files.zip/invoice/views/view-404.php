<?php

echo 'i am 404';
