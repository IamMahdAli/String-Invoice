<?php


// getting header
get_header2($routerController);

// body for invoice
get_body('is_index') ;

// footer
get_footer('is_index');

