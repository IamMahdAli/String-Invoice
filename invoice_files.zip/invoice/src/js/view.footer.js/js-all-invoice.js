$(function () {

    var tableName = 'invoiceInfo';
     var url = '/invoice/core/models/model-thread-records.php';

    // main ajax request
    $.ajax({
        method: "POST",
        url: url,
        dataType: 'json',
        data: {
            tableName: tableName
        },

        // functions running after succes must be under main success function
        success: function (data) {

            $('#threadRecordsTable').dataTable({
                data: data,
                async: false,
                // columns of the table and then rendering them
                columns: [
                    {'data': 'InvoiceNo',
                        'sorting': false,
                        "render": function (id) {
                            return '<input type="checkbox" name="tableCheckBoxNo' + id + ' " value="' + id + '"  > ';
                        }
                    },
                    {'data': 'InvoiceNo'},
                    {'data': 'invoiceUpdated'},
                    {'data': 'invoiceDate'},
                    {'data': 'invoiceName'},
                    {'data': 'invoiceDescription',
                        'render': function(data) {
                            return '<div> ' + data + ' </div>'
                        }},
                    {'data': 'InvoiceNo',
                        'render': function (data) {
                            return '<a target="_blank" style="margin-bottom: 1rem" class="button is-info is-small is-radiusless tableEditButton"  href="get-invoice/invoice-no/' + data + '" > &nbsp; View &nbsp;</a> '
                                +
                                '<button onclick="return confirm(\'Are you sure?\')" class="button is-danger is-small is-radiusless tableDeleteButton" value="' + data + '"> Delete </button>'
                        }},

                ]
            });

            // deleting main button
            $('.tableDeleteButton').on('click', function (event) {
                event.preventDefault();

                var id = $(this).attr('value');

                $.ajax({
                    type: "POST",
                    dataType: 'json',
                    url: deleteInvoice,
                    data: {id: id},
                    success: function (data) {
                        var tableStatus = $('#tableStatus');
                        if (data == 1) {
                            tableStatus.empty();
                            tableStatus.append('Deleted Successfully!');
                        } else {
                            tableStatus.empty();
                            $('#tableStatus').append('Failure While Delteing!');
                        }
                    },
                    error: function (data) {
                        tableStatus.empty();
                        tableStatus.append('Something Went Wrong!!');

                    }
                    //    error for deleting  table button
                });


            });
            //    other function after success

            $('.threadDeleteAll').on('click', function () {
                var checkedStatus = this.checked;
                $("input:checkbox").prop("checked", checkedStatus);
            });

            // checking checkbixes


            $('#deleteAll').on('click', function () {

                var checkBoxChecked = $('input[type="checkbox"]:checked');
                var statusDiv = $('#status');

                if (checkBoxChecked.length   === 0 ) {
                    alert('Please Select Atleast One Checkbox To Delete ');
                }

                checkBoxChecked.each(function () {
                    var result = $(this).attr('value');

                    $.ajax({
                        type: "POST",
                        dataType: 'json',
                        data: {id: result,
                            table: 'invoiceInfo'},
                        cache: false,

                        url: deleteInvoice,
                        success: function () {
                            statusDiv.empty();
                            statusDiv.append('Record(s) Deleted Sucessfully!, Please Reload.')
                        },
                        error: function () {
                            statusDiv.empty();

                            statusDiv.append('Could Not Delete Record(s)!');

                        }
                    });


                })
            });

            //    other function after success

        },
        error: function (xhr, status, error) {
            alert('Nothing Found!');
        }
        // main error
    });




});


