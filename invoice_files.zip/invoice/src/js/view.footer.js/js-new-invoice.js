// initiate bulma calender extension


$(function () {





    // Initialize all input of type date
    var calendars = bulmaCalendar.attach('[type="date"]', {
            startDate: new Date(), // Date selected by default
            dateFormat: 'DD/MM/YYYY', // the date format `field` value
            lang: 'en', // internationalization

        }

    );




    // getting and updating total
    var quantityValue = $('#invouceQuantity1');
    quantityValue.on('keyup', function () {
        var quantityValue = $(this).val();
        var invoicePerPack = perPack.val();

        var total = quantityValue * invoicePerPack;
        totalBox.val(total);

    });


    // vars for to make functionality work
    var createRows = $('#createRows');
    var toAdd   = $('#noOfRows');
    var tableBody = $('#tableBody');
    var fetchedRows = 0;
    var totalRowsAdded = 0;
    var rowsAdded = 1;
    var maxAllowedRows  = 10;
    var loopTurn = 0;


//     even on click at createRows button
createRows.on('click', function (event) {
        event.preventDefault();
    //     fetching row
    var  fetchedRows = toAdd.val();

    var rowsToadd = parseInt(fetchedRows)  ;
    // checking if required rows are greater then allowed rows
    if (rowsToadd  <= maxAllowedRows ) {

    //     iterating
    while ( loopTurn  <= maxAllowedRows ) {
        if (loopTurn >= fetchedRows ) {
            break;
        }




        tableBody.append(
            '<tr id="tableRow' + loopTurn  +  '">\n' +
            '\n' +
            '                                    <td> ' + loopTurn + ' </td>\n' +
            '                                    <td>\n' +
            '                                        <input type="text" class="input is-primary " placeholder="E.g Thread color" maxlength="100" id="invoiceDetailName'+ loopTurn + '"  value="" name="invoiceDetailName'+ loopTurn + '">\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input class="input  is-primary " style="" type="number" placeholder="E.g 256" name="invoiceNumberName'+ loopTurn + '" id="invoiceNumberName'+ loopTurn + '" value="" >\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input  type="number" class="input is-primary" placeholder="E.g 14" name="invoiceQuantityName'+ loopTurn + '" value="" id="invoiceQuantityName'+ loopTurn + '">\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input id="invoicePerPack'+ loopTurn + '"  type="number"  name="invoicePerPack'+ loopTurn + '"  class="input is-primary " value="">\n' +
            '                                    </td>\n' +
            '\n' +
            '                                    <td>\n' +
            '                                        <input type="number"  name="invoiceTotal'+ loopTurn + '" id="invoiceTotal'+ loopTurn + '"  class="input is-primary " value="">\n' +
            '\n' +
            '                                    </td>\n' +
            '\n' +
            '                                    <td>\n' +
            '                                        <input type="checkbox" name="checkBoxNo'+ loopTurn + '" value="'+ loopTurn + '" id="checkBox'+ loopTurn + '">\n' +
            '                                    </td>\n' +
            '                                </tr>'
        );


        loopTurn++;
        totalRowsAdded++;


    }




        } else {

            alert('Only Uptill From 1 to 10 Rows Are Allowed!')

        }




})

//     delete functionality
    var btnRemoveRow = $('#btnRemoveRow');

    btnRemoveRow.on('click', function(event) {
        event.preventDefault();

        var checkBoxChecked = $('input[type="checkbox"]:checked');


        if (checkBoxChecked.length === 0 ) {
            alert('Please Select Atleast One Checkbx To Delete Atleast One Row!')
        }

        checkBoxChecked.each( function(index, element) {
            var toDelete = $(this).attr('value');
            var trToRemove = $('#tableRow' + toDelete + '');

            // if you wants to restore just check detach and then restore
            var restoreFromDetach = trToRemove.detach();


        });


    });


    // var allThreadNo = $('input[id^="invoiceNumberName"]');
    // var allThreadNo = $('tbody #id^invoiceNumberName');

    // var allQuantityNo = $('input[id^="invoiceQuantityName"]');
    var allQuantityNoStart = "invoiceQuantityName";
    var allTotalNoStart = "invoiceTotal";
    // var perPack = $('#invoicePerPack1');
    var allPerPackStarting = 'invoicePerPack';

    // $(document).on('keypress','input[id^="invoiceNumberName"]', function () {
    $(document).on('keyup','input[id^="invoice"]', function () {

        var thisThreadNo = $(this).attr('id');

        var threadId = thisThreadNo[thisThreadNo.length -1];


            var hereThreadId = 'invoiceNumberName'+threadId+'';


           var forThisThreaNoQuanityBoxIS = 'invoiceQuantityName'+threadId+'';
           var forThisPerPackIs = 'invoicePerPack'+threadId+'';
           var forThisTotalIs = 'invoiceTotal'+threadId+'';
           var forThisThreadNoIs = 'invoiceNumberName'+threadId+''





        var getThisThreadNo = $('#'+forThisThreadNoIs+'');
        var getThisQuantity = $('#'+forThisThreaNoQuanityBoxIS+'');
        var getThisPerPack = $('#'+forThisPerPackIs+'');
        var getThisTotal = $('#'+forThisTotalIs+'');

        var status = $('#status');


        // getting data from thread no on having any number
           var threadNovalue = getThisThreadNo.val();

            $.ajax({
                type: "POST",
                dataType: 'json',
                url: urlFetch,
                data: {threadNo: threadNovalue},
                success: function (result) {
                    if (result === 'err') {

                        status.empty();
                        status.append('  &nbsp;&nbsp; Not a thread number!');
                    } else  {
                        status.empty();
                        status.append('  &nbsp;&nbsp;  Updated!')
                    }

                    $.each(result, function (index, value) {

                        getThisPerPack.val(value.threadPerPack);

                        value = null;


                    })


                    var gottenPerPack = getThisPerPack.val();

                    var gottenQuantity = getThisQuantity.val();

                    var rowTotal = gottenPerPack * gottenQuantity;

                    getThisTotal.val(rowTotal);

                },
                error: function (response) {

                    if ( response == 'wrong' ) {

                        alert('Something Went Wrong!')
                    }
                }
            });






    });

    // total calculation and its functionality
    var tableBody = $('#tableBody');

    var subTotalBox = $('#invoiceSubTotal');
    var totalBox = $('#invoiceTotal');

    $('#btnCalTotal').on('click', function() {
        var invoiceTotal = 0;
        var result = tableBody.find('td:nth-last-child(2) input').each( function(index, value) {

            var boxVal = $(this).val();
            var intedVal =  parseInt(boxVal);
            console.log(intedVal);

            invoiceTotal = invoiceTotal + intedVal;
        } ) ;

        subTotalBox.val(invoiceTotal);
        console.log(userDescription + ' userDescription');

    });






    $('#submitInvoice').on('click', function(event) {
        event.preventDefault();

        var mySubtotal = subTotalBox.val();
        var myTotal = totalBox.val();
        var userDescription = $('#descriptionForuser').val();

        console.log(mySubtotal)
        console.log(myTotal)
        var invoiceDate = $('.datetimepicker-dummy-input').val();
        var invoiceName = $('#invoiceNamenn').val();

        if (invoiceName && myTotal && mySubtotal ) {


        $.ajax({
            type: "POST",
            dataType: 'json',
            url: createInvoice,
            data: {invoiceName: invoiceName,
                invoiceDate: invoiceDate,
                invoiceSubtotal: mySubtotal,
                myTotal: myTotal,
                description: userDescription
            },

            success: function (data, status, jqXHR) {

                debugger
                alert('Invoice Created!')
                var dataToDb = Array();
                var InvoiceCreated = false;
                var loopCounter = $("#noOfRows").val();

                for (var i = 0; i < loopCounter ; i++) {

                    var workingRow = $("#tableRow"+i );

                    workingRow.find("td input").each(function(index, value) {
                        dataToDb[index] = Array();
                        $(this).each(function(ii, v) {
                            dataToDb[index][ii] = $(this).val();
                        });

                        dataToDb[0][index] = $(this).val();
                    });

                    dataToDb[0][6] = data;

                    if ( dataToDb[0] ) {

                    $.ajax({
                        type: "POST",
                        dataType: 'json',
                        url: createInvoiceRows,
                        data: {
                            data: dataToDb[0]
                        },
                        success: function (result) {


                        },
                        error: function (response) {
                            // multiple rows
                            alert('Empty row detected. cannot create invoice. Please fill all invoice rows')

                        }
                    });
                    } else {
                        alert('Invoice rows cannot be empty')
                        debugger
                    }


                }


            },
            error: function (response) {
                // metadata
                debugger

                if ( response == 'wrong' ) {

                    alert('Something Went Wrong!')
                }
            }
        });

        } else {
            console.log(mySubtotal + ' mySubtotal')
            console.log(myTotal + ' myTotal')
            console.log(invoiceName + ' invoiceName')
            alert('Name, Subtotal and Total can not be empty!')
        }

    })




});


// $('#'+thisThreadNo+'')