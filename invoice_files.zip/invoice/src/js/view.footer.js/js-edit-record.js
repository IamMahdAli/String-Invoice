$(function () {


    var threadComment = $('#threadComment');
    var threadPerPack = $('#threadPerPack');
    var threadInStock = $('#threadInStock');
    var threadNumber  = $('#threadNumber');

    $.ajax({
        type: "POST",
        url: urlGetThread,
        dataType: 'json',
        data: {id: routerParams},
        success: function (data) {

            $.each(data,  function (index, item) {

                threadComment.val(item.threadComment);
                threadPerPack.val(item.threadPerPack);
                threadInStock.val(item.threadInStock);
                threadNumber.val(item.threadNo);

                });
        },
        error: function () {
            alert('something went wrong');
        }

    });

    $('#threadupdate').on('click', function (event) {
        event.preventDefault();
        var myData = $('#formUpdateRecord').serialize();

        $.ajax({
           type: "POST",
           url: updateUrl,
            dataType: 'json',
            data: myData,

            success: function (data) {
               var status = $('#status');
                status.empty();
                status.append('Updated Successfully!')
            },
            error: function (data) {
                var status = $('#status');
                status.empty();
                status.append('Failed!, You Can Not Update Thread No!')

            }
        });
    })
});