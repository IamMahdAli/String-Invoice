$(function () {

    var tableName = 'threadRecords';
    var url = '/invoice/core/models/model-thread-records.php';

        // main ajax request
        $.ajax({
            method: "POST",
            url: url,
            dataType: 'json',
            data: {
                tableName: tableName
            },

            // functions running after succes must be under main success function
            success: function (data) {

                $('#threadRecordsTable').dataTable({
                    data: data,
                    async: false,
                    // columns of the table and then rendering them
                    columns: [
                        {'data': 'id',
                            'sorting': false,
                        "render": function (id) {
                          return '<input type="checkbox" name="tableCheckBoxNo' + id + ' " value="' + id + '"  > ';
                        }
                        },
                        {'data': 'threadModified',
                            "searchable": false,
                        "render": function (time) {
                            var day = time.substr(0,10);
                            var hours = time.substr( -8, 8 );
                            return 'Day '  + day +  ' Time ' + hours + ' '
                        }},
                        {'data': 'threadPerPack',
                        "render": function (amount) {
                            return 'Rs' + amount + ' '
                        }},
                        {'data': 'threadInStock'},
                        {'data': 'threadComment',

                            "sorting": false,
                        "render": function (comment) {
                            if (comment.length > 25) {
                                var minComment = comment.substr(0, 25);
                                return  minComment + '...'
                            } else {
                                return comment
                            }
                        }
                        },
                        {'data': 'threadNo'},
                        {'data': 'id',
                        'render': function (data) {
                            return '<a target="_blank" style="margin-bottom: 1rem" class="button is-info is-small is-radiusless tableEditButton"  href="edit-record/get-thread/' + data + '" > &nbsp; Edit &nbsp;</a> '
                              +
                                '<button onclick="return confirm(\'Are you sure?\')" class="button is-danger is-small is-radiusless tableDeleteButton" value="' + data + '"> Delete </button>'
                        }}
                    ]
                });

                // deleting main button
                $('.tableDeleteButton').on('click', function (event) {
                    event.preventDefault();

                    var id = $(this).attr('value');

                    $.ajax({
                        type: "POST",
                        dataType: 'json',
                        url: deleteUrl,
                        data: {id: id},
                        success: function (data) {
                            var tableStatus = $('#tableStatus');
                            if (data == 1) {
                                tableStatus.empty();
                                tableStatus.append('Deleted Successfully!');
                            } else {
                                tableStatus.empty();
                                $('#tableStatus').append('Failure While Delteing!');
                            }
                        },
                        error: function (data) {
                            tableStatus.empty();
                            tableStatus.append('Something Went Wrong!!');

                        }
                    //    error for deleting  table button
                    });


                });
            //    other function after success

                $('.threadDeleteAll').on('click', function () {
                    var checkedStatus = this.checked;
                   $("input:checkbox").prop("checked", checkedStatus);
                });

                // checking checkbixes


                $('#deleteAll').on('click', function () {

                    var checkBoxChecked = $('input[type="checkbox"]:checked');
                    var statusDiv = $('#status');

                    if (checkBoxChecked.length   === 0 ) {
                        alert('Please Select Atleast One Checkbox To Delete ');
                    }

                    checkBoxChecked.each(function () {
                        var result = $(this).attr('value');

                        alert(result)
                            $.ajax({
                                type: "POST",
                                dataType: 'json',
                                data: {id: result,
                                table: 'threadRecords'},
                                cache: false,

                                url: deleteMultiple,
                                success: function () {
                                    statusDiv.empty();
                                    statusDiv.append('Record(s) Deleted Sucessfully!, Please Reload.');
                                    alert('Deleted Successfully!')
                                },
                                error: function () {
                                    statusDiv.empty();

                                    statusDiv.append('Could Not Delete Record(s)!');

                                }
                            });


                    })
                });

                //    other function after success

            },
            error: function (xhr, status, error) {
                alert('Nothing Found!');
            }
        // main error
        });



});


