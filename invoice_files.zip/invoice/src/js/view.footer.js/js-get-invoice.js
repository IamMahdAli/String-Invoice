$(function () {


 var invoiceNo = $('#invoiceNo');
 var invoiceNoToDelete = $('#invoiceNoToDelete');
 var invoiceName = $('#invoiceName');
 var invoiceCreatedDate = $('#invoiceCreatedDate');
 var invoiceNoForDeletion = $('#invoiceNoForDeletion');
 var descriptionBox = $('#descriptionForuser');
 var subTotalBox = $('#invoiceSubTotal');
 var totalBox = $('#invoiceTotal');

 $.ajax({
  type: "POST",
  url: urlGetInvoice,
  dataType: 'json',
  data: {id: routerParams},
  success: function (data) {


   $.each(data,  function (index, item) {

    invoiceNo.val(item.InvoiceNo);
    invoiceNoToDelete.val(item.InvoiceNo);
    invoiceNoForDeletion.val(item.InvoiceNo);
    invoiceName.val(item.invoiceName);
    invoiceCreatedDate.val(item.invoiceDate);
    descriptionBox.val(item.invoiceDescription);
    subTotalBox.val(item.invoiceSubtotal);
    totalBox.val(item.invoiceTotal);




   });
   var invoiceNoIs = $('#invoiceNo').val();


   $.ajax({
    type: "POST",
    url: urlGetInvoiceRows,
    dataType: 'json',
    data: {invoiceNo: invoiceNoIs},
    success: function (data, textStatus, jqXHR) {

     var noOfRows = jqXHR.responseJSON.length;

     var toAdd   = $('#noOfRows');
     var tableBody = $('#tableBody');
     var fetchedRows = 0;
     var totalRowsAdded = 0;
     var rowsAdded = 1;
     var maxAllowedRows  = 10;
     var loopTurn = 0;

     //     even on click at createRows button
      function createRows() {

      //     fetching row
      var  fetchedRows = noOfRows;

      var rowsToadd = parseInt(fetchedRows) ;
      // checking if required rows are greater then allowed rows
      if (rowsToadd  <= maxAllowedRows ) {

       //     iterating
       while ( loopTurn  <= maxAllowedRows ) {
        if (loopTurn >= fetchedRows ) {
         break;
        }




        tableBody.append(
            '<tr id="tableRow' + loopTurn  +  '">\n' +
            '\n' +
            '                                    <td> ' + loopTurn + ' </td>\n' +
            '                                    <td>\n' +
            '                                        <input type="text" class="input is-primary " placeholder="E.g Thread color" maxlength="100" id="invoiceDetailName'+ loopTurn + '"  value="" name="invoiceDetailName'+ loopTurn + '">\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input class="input  is-primary " style="" type="number" placeholder="E.g 256" name="invoiceNumberName'+ loopTurn + '" id="invoiceNumberName'+ loopTurn + '" value="" >\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input  type="number" class="input is-primary" placeholder="E.g 14" name="invoiceQuantityName'+ loopTurn + '" value="" id="invoiceQuantityName'+ loopTurn + '">\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input id="invoicePerPack'+ loopTurn + '"  type="number"  name="invoicePerPack'+ loopTurn + '"  class="input is-primary " value="">\n' +
            '                                    </td>\n' +
            '\n' +
            '                                    <td>\n' +
            '                                        <input type="number"  name="invoiceTotal'+ loopTurn + '" id="invoiceTotal'+ loopTurn + '"  class="input is-primary " value="">\n' +
            '\n' +
            '                                    </td>\n' +
            '\n' +
            '                                </tr>'
        );


        loopTurn++;
        totalRowsAdded++;


       }




      } else {

       alert('SOmething went wrong!')

      }




     }
     createRows(); // crating rows

     var myRowNo = 0;

      // adding into rows
      $.each(jqXHR.responseJSON, function(index, value){
       var rowToInput = $('#tableRow' + myRowNo + '');
       var invoiceDetailNameBox = $('#invoiceDetailName'+myRowNo);
       var invoiceNumberNameBox = $('#invoiceNumberName'+myRowNo);
       var invoiceQuantityNameBox = $('#invoiceQuantityName'+myRowNo);
       var invoicePerPackBox = $('#invoicePerPack'+myRowNo);
       var invoiceTotalBox = $('#invoiceTotal'+myRowNo);
       var checkBoxNoBox = $('#checkBoxNo'+myRowNo);

       invoiceDetailNameBox.val(value.invoiceRowDetails);
       invoiceNumberNameBox.val(value.invoiceThreadNo);
       invoiceQuantityNameBox.val(value.invoiceRowQuantity);
       invoicePerPackBox.val(value.invoiceRowPerPack);
       invoiceTotalBox.val(value.invoiceRowTotal);
       checkBoxNoBox.val(value.rowNo);


        myRowNo++;

      });



    }, // error Invoice Rows
    error: function (jqXHR, textStatus, errorThrown) {

     //


     if ( jqXHR.responseJSON == 'no') {
      alert('No invoice row found')
     }  else {
      alert('something went wrong');
     }
    }

   }); // end rows ajax req



  }, // error invoiceInfo
  error: function () {
   alert('something went wrong');
  }

 }); // end invoice ajax req

});