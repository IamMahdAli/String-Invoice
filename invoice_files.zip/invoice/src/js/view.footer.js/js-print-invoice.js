$(function () {



    var invoiceNo = $('#invoiceNo');
    var invoiceName = $('#clientName');
    var invoiceCreatedDate = $('#invoicedate');
    var subTotal = $('#subTotal');
    var total = $('#invoiceTotal');
    var total2 = $('#total');
    var dueAmount = $('#dueAmount');

    $.ajax({
        type: "POST",
        url: urlGetInvoice,
        dataType: 'json',
        data: {id: routerParams},
        success: function (data) {


            $.each(data,  function (index, item) {

                invoiceNo.html(item.InvoiceNo);
                invoiceName.html(item.invoiceName);
                invoiceCreatedDate.html(item.invoiceDate);
                $('#subTotal').html(item.invoiceSubtotal);
                total.html(item.invoiceTotal);
                total2.html(item.invoiceTotal);
                dueAmount.html(item.invoiceTotal);




            });
            var invoiceNoIs = $('#invoiceNo').html();
            console.log(invoiceNoIs)


            $.ajax({
                type: "POST",
                url: urlGetInvoiceRows,
                dataType: 'json',
                data: {invoiceNo: invoiceNoIs},
                success: function (data, textStatus, jqXHR) {

                    var noOfRows = jqXHR.responseJSON.length;

                    var toAdd   = $('#noOfRows');
                    var tableBody = $('#tableBody');
                    var fetchedRows = 0;
                    var totalRowsAdded = 0;
                    var rowsAdded = 1;
                    var maxAllowedRows  = 10;
                    var loopTurn = 0;

                    //     even on click at createRows button
                    function createRows() {

                        //     fetching row
                        var  fetchedRows = noOfRows;

                        var rowsToadd = parseInt(fetchedRows) ;
                        // checking if required rows are greater then allowed rows
                        if (rowsToadd  <= maxAllowedRows ) {

                            //     iterating
                            while ( loopTurn  <= maxAllowedRows ) {
                                if (loopTurn >= fetchedRows ) {
                                    break;
                                }




                                tableBody.append(
                                    '<tr id="tableRow' + loopTurn  +  '">\n' +
                                    '\n' +
                                    '                                    <td> ' + loopTurn + ' </td>\n' +
                                    '                                    <td>\n' +
                                    '                                        <input type="text" class="input  " placeholder="E.g Thread color" maxlength="100" id="invoiceDetailName'+ loopTurn + '"  value="" name="invoiceDetailName'+ loopTurn + '">\n' +
                                    '                                    </td>\n' +
                                    '                                    <td>\n' +
                                    '                                        <input class="input   " style="" type="number" placeholder="E.g 256" name="invoiceNumberName'+ loopTurn + '" id="invoiceNumberName'+ loopTurn + '" value="" >\n' +
                                    '                                    </td>\n' +
                                    '                                    <td>\n' +
                                    '                                        <input  type="number" class="input " placeholder="E.g 14" name="invoiceQuantityName'+ loopTurn + '" value="" id="invoiceQuantityName'+ loopTurn + '">\n' +
                                    '                                    </td>\n' +
                                    '                                    <td>\n' +
                                    '                                        <input id="invoicePerPack'+ loopTurn + '"  type="number"  name="invoicePerPack'+ loopTurn + '"  class="input  " value="">\n' +
                                    '                                    </td>\n' +
                                    '\n' +
                                    '                                    <td>\n' +
                                    '                                        <input type="number"  name="invoiceTotal'+ loopTurn + '" id="invoiceTotal'+ loopTurn + '"  class="input  " value="">\n' +
                                    '\n' +
                                    '                                    </td>\n' +
                                    '\n' +
                                    '                                </tr>'
                                );


                                loopTurn++;
                                totalRowsAdded++;


                            }




                        } else {

                            alert('SOmething went wrong!')

                        }




                    }
                    createRows(); // crating rows

                    var myRowNo = 0;

                    // adding into rows
                    $.each(jqXHR.responseJSON, function(index, value){
                        var rowToInput = $('#tableRow' + myRowNo + '');
                        var invoiceDetailNameBox = $('#invoiceDetailName'+myRowNo);
                        var invoiceNumberNameBox = $('#invoiceNumberName'+myRowNo);
                        var invoiceQuantityNameBox = $('#invoiceQuantityName'+myRowNo);
                        var invoicePerPackBox = $('#invoicePerPack'+myRowNo);
                        var invoiceTotalBox = $('#invoiceTotal'+myRowNo);
                        var checkBoxNoBox = $('#checkBoxNo'+myRowNo);

                        invoiceDetailNameBox.val(value.invoiceRowDetails);
                        invoiceNumberNameBox.val(value.invoiceThreadNo);
                        invoiceQuantityNameBox.val(value.invoiceRowQuantity);
                        invoicePerPackBox.val(value.invoiceRowPerPack);
                        invoiceTotalBox.val(value.invoiceRowTotal);
                        checkBoxNoBox.val(value.rowNo);


                        myRowNo++;

                    });



                }, // error Invoice Rows
                error: function (jqXHR, textStatus, errorThrown) {

                    //


                    if ( jqXHR.responseJSON == 'no') {
                        alert('No invoice row found')
                    }  else {
                        alert('something went wrong');
                    }
                }

            }); // end rows ajax req



        }, // error invoiceInfo
        error: function () {
            alert('something went wrong');
        }

    }); // end invoice ajax req

    $('#printButton').on('click', function() {



    });

    function printInvoice() {
        window.print();
    }

    printInvoice();

});


