$(function () {

 $('#threadSubmit').on('click', function (e) {

     e.preventDefault();
     var threadComment = $('#threadComment').val();
     var threadPerPack = $('#threadPerPack').val();
     var threadInStock = $('#threadInStock').val();
     var threadNumber = $('#threadNumber').val();

    if (threadNumber != '' &&  threadInStock != '' &&  threadPerPack != '' &&  threadComment != '') {

        var form = $('#formInsertNewRecord');

        $.ajax({

            url: form.attr('action'),
            type: 'post',
            data: {
                // data: $('#formInsertNewRecord').serialize()
                    threadComment: threadComment,
                    threadPerPack: threadPerPack,
                    threadInStock: threadInStock,
                    threadNumber: threadNumber
            },

          success: function (data) {
                    var allInput = $(':input');
                    var submit =  $('input#threadSubmi');

                        allInput.val("");

              var status = $('#status');
              status.empty();
              status.append('New Thread Has Been Added!')

          },
            error: function(data) {
                      var status = $('#status');

                      status.empty();
        $('#status').append('Thread No already Exists, Please Try Something Else!')
            }
        })

    } else {
        var status = $('#status');
        status.empty();

        status.append('No Field Must Be Empty!')

    }


 })

});


// $(function () {
//
//     $('#threadSubmit').on('click', function () {
//
//
//         var threadComment = $('#threadComment').val();
//         var threadPerPack = $('#threadPerPack').val();
//         var threadInStock = $('#threadInStock').val();
//         var threadNumber = $('#threadNumber').val();
//         debugger
//
//         if (threadNumber != '' &&  threadInStock != '' &&  threadPerPack != '' &&  threadComment != '') {
//
//             var form = $('#formInsertNewRecord');
//             debugger
//
//             $.ajax({
//
//                 url: form.attr('action'),
//                 type: 'post',
//                 dataType: 'json',
//                 data: {
//                     // data: $('#formInsertNewRecord').serializeArray()
//                     threadComment: threadNumber,
//                     threadPerPack: threadPerPack,
//                     threadInStock: threadInStock,
//                     threadNumber: threadNumber
//                 },
//                 success: function (data) {
//                     debugger
//
//                     alert('yeeey');
//                 }
//
//             })
//
//         } else {
//             alert('no')
//
//         }
//
//
//     })
//
// });