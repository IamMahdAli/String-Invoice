// code to display content on click on hamberger at small devices

$(function () {

    $('#navBurger').on('click', function () {

        $(this).toggleClass('is-active');

        $('#upperNav').toggleClass('is-active');

    })
});

