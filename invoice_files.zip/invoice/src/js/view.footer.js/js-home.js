$(function () {

    $.ajax({
        type: "POST",
        url: urlGetRowNo,
        dataType: 'json',
        data: {tableName: 'invoiceInfo'},
        success: function (data) {

            $('#invoiceTotalNo').html(data);
            console.log( data)
        },
        error: function () {
            alert('something went wrong');
        }

    });


    $.ajax({
        type: "POST",
        url: urlGetRowNo,
        dataType: 'json',
        data: {tableName: 'threadRecords'},
        success: function (data) {

            $('#threadTotalNo').html(data);
            console.log( data)
        },
        error: function () {
            alert('something went wrong');
        }

    });

});
