
// passing var
function passVar1($varToPass) {
    return $varToPass;

}