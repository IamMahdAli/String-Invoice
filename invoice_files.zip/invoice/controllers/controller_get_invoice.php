<?php


$routerController = routerController();
$routerMethod = routerMethod();


if (isset($routerMethod) && $routerMethod != null) {

    $routerParams = routerParams();
}


require VIEWS . 'view-' . $routerController . '.php';

