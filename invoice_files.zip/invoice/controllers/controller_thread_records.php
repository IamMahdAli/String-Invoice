<?php

$routerController = routerController();

$datas = getData($routerController);

require VIEWS . 'view-'. $routerController . '.php';

