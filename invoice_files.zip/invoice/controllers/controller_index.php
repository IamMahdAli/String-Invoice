<?php

require VIEWS . 'view-index.php';

