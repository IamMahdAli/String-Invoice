<?php

$routerController = routerController();
require VIEWS . 'view-' . $routerController . '.php';
