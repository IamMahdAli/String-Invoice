<?php

require 'db.php';

try {

    $data = [
      'id' => $_POST['id']
    ];

    $stmt = $pdo->prepare('DELETE FROM invoiceInfo WHERE InvoiceNo = :id ');

    $stmt->execute($data);

    $stmt = $pdo->prepare('DELETE FROM invoiceRowsData WHERE InvoiceNo = :id ');

    $stmt->execute($data);

    if ($stmt) {
        echo json_encode('1');
    } else {
        echo json_encode('0');
    }

} catch (Exception $e) {
    header('HTTP/1.0 400 Something Went Wrong');
}
