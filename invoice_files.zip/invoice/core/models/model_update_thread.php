<?php

header('Content-Type: application/json');

require 'db.php';

$data = [

'threadComment' => $_POST['threadComment'],
'threadPerPack' => $_POST['threadPerPack'],
'threadInStock' => $_POST['threadInStock'],
'threadNumber' => $_POST['threadNumber']
];

try {

    $stmt = $pdo->prepare('UPDATE threadRecords SET threadComment= :threadComment, threadPerPack= :threadPerPack,
threadInStock= :threadInStock WHERE threadNo = :threadNumber  ');
    $stmt->execute($data);

    if ($stmt) {
        echo json_encode('success');

    } else {
        echo json_encode('error');

    }



} catch (EXCEPTION $e) {

    header('HTTP/1.0 400 Something Went Wrong');

}
