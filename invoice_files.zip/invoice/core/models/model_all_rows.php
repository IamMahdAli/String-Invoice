<?php

header('Content-Type: application/json');

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    try {
    $tableName = $_POST['tableName'];

        $stmt = $pdo->query('SELECT COUNT(*) FROM ' . $tableName . ' ');

        $stmt= $stmt->fetchColumn();

        if (!$stmt) {
            header('HTTP/1.0 400 Something Went Wrong');
            echo 'noo';
        }

        print_r(json_encode($stmt));

    }

    catch (EXCEPTION $e) {
        echo json_encode($e->getMessage());
        header('HTTP/1.0 400 Something Went Wrong ');
    }


}

//$stmt = $dbo->query($sqlAll);
//$num_rows = $stmt->fetchColumn();