<?php

header('Content-Type: application/json');

require  'db.php';

try {

$id = $_POST['invoiceNo'];

$data = [
  'invoiceNo' => $id
];

$stmt = $pdo->prepare('SELECT * FROM invoiceRowsData WHERE InvoiceNo = :invoiceNo ');

$stmt->execute($data);

$data = $stmt->fetchAll();

if (!$data) {
    throw new EXCEPTION('no');

}

echo(json_encode($data));

} catch (EXCEPTION $e) {
    echo json_encode($e->getMessage());
    header('HTTP/1.0 400 Something Went Wrong ');
}
