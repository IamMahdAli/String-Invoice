<?php

header('Content-Type: application/json');

require 'db.php';

try {

    $data = [
        'threadNo' => $_POST['threadNo']
    ];

    $stmt = $pdo->prepare('SELECT * FROM threadRecords WHERE threadNo = :threadNo ');

    $stmt->execute($data);

   $output =  $stmt->fetchAll();

    if ($output)
    echo json_encode($output);
    else
        echo json_encode('err');


} catch (Exception $e) {
    echo json_encode('wrong');
    header('HTTP/1.0 400 Something Went Wrong');
}