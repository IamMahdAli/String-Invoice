<?php

header('Content-Type: application/json');

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $tableName = $_POST['tableName'];

        $stmt = $pdo->query('SELECT * FROM ' . $tableName . ' ');

        $stmt= $stmt->fetchAll();

        if (!$stmt) {
            header('HTTP/1.0 400 Something Went Wrong');
        }

        print_r(json_encode($stmt));

}