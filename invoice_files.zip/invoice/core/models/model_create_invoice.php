<?php

require  'db.php' ;

try {

    global $pdo;

    if ( isset($_POST['invoiceName']) ) {

    $data = [
        'invoiceName' => $_POST['invoiceName'],
        'invoiceDate' => $_POST['invoiceDate'],
        'invoiceSubtotal' => $_POST['invoiceSubtotal'],
        'total' => $_POST['myTotal'],
        'userDescription' => $_POST['description']
    ];


    // inserting metadata for invoice
    $sql = 'INSERT INTO invoiceInfo ( invoiceName, invoiceDate, invoiceSubtotal, invoiceTotal, invoiceDescription )
 VALUES( :invoiceName, :invoiceDate, :invoiceSubtotal, :total, :userDescription )';

    $stmt = $pdo->prepare($sql);
    if (!$stmt->execute($data)) {
        return false;
    } else {
        echo json_encode($pdo->lastInsertId());
    }

    }

}

catch (EXCEPTION $e) {
    header('HTTP/1.0 400 Something Went Wrong ');
}
