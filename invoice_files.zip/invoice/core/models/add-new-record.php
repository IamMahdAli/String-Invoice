<?php

require  'db.php' ;


try {

    global $pdo;
    $data = [
        'threadComment' => $_POST['threadComment'],
        'threadPerPack' => $_POST['threadPerPack'],
        'threadInStock' => $_POST['threadInStock'],
        'threadNumber' => $_POST['threadNumber'],
        'threadModified' => date('Y-m-d H:i:s', time())
    ];


    $sql = 'INSERT INTO threadRecords (threadNo, threadPerPack, threadComment, threadModified, threadInStock)
 VALUES(:threadNumber,
:threadPerPack, :threadComment, :threadModified, :threadInStock)';

    $stmt = $pdo->prepare($sql);
    if (!$stmt->execute($data))
    return false;
}

catch (EXCEPTION $e) {

    header('HTTP/1.0 400 Something Went Wrong');

}









