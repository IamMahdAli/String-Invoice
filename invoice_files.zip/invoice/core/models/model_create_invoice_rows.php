<?php

require  'db.php' ;

try {

    global $pdo;

        // row data from js file witj Ajax
        $invoiceRowData = $_POST['data'];

        $singleRowDataToEnter = [
            'detail' => $invoiceRowData[0],
            'threadNo' => $invoiceRowData[1],
            'quantity' => $invoiceRowData[2],
            'perPack' => $invoiceRowData[3],
            'total' => $invoiceRowData[4],
            'thisRowNo' => $invoiceRowData[5],
            'invoiceNo' => $invoiceRowData[6]
        ];



        $stmt = $pdo->prepare("INSERT INTO invoiceRowsData ( invoiceRowDetails, invoiceThreadNo, invoiceRowQuantity
 , invoiceRowPerPack, invoiceRowTotal, rowNo, invoiceNo)
 VALUES( :detail, :threadNo, :quantity, :perPack, :total, :thisRowNo, :invoiceNo )");

        if ($stmt->execute($singleRowDataToEnter)) {
            echo json_encode('done');
        } else {
            throw new PDOException();
        }


}

catch (EXCEPTION $e) {
    echo $e->getMessage();
    echo json_encode('wrong');

//    $pdo->rollback();
    echo json_encode($e->getMessage());
    echo $e->getMessage();

    header('HTTP/1.0 400 Something Went Wrong ');

}
