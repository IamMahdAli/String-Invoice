<?php

header('Content-Type: application/json');

require  'db.php';

$id = $_POST['id'];

$data = [
  'invoiceNo' => $id
];

$stmt = $pdo->prepare('SELECT * FROM invoiceInfo WHERE InvoiceNo = :invoiceNo ');

$stmt->execute($data);

$data = $stmt->fetchAll();

if (!$data) {
    header('HTTP/1.0 400 Something Went Wrong');

}

echo(json_encode($data));


