<?php


header('Content-Type: application/json');

require 'db.php';

$fromTableToDelete = $_POST['table'];

try {


    $data = [
      'id' => $_POST['id']
    ];
$stmt = $pdo->prepare("DELETE  FROM $fromTableToDelete  WHERE id = :id");

if ($stmt->execute($data))

    echo json_encode('success');


} catch (EXCEPTION $e) {
    echo json_encode($e->getMessage());
    header('HTTP/1.0 400 Something Went Wrong');
}
