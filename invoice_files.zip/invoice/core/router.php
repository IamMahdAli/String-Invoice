<?php

require INDEX;
require CORE . 'routes.php';


// getting controller to be used
function routerController() {

    global $url;

    $routerController = isset($url[0]) ? $url[0] : DEFAULT_VALUE;
    return $routerController;
}


// getting router method
function routerMethod() {

    global $url;

    $routerMethod = isset($url[1]) ? $url[1] : DEFAULT_VALUE;
    return $routerMethod;
}


// getting router param
function routerParams() {

    global $url;

    $routerParam = isset($url[2]) ? $url[2] : DEFAULT_VALUE;
    return $routerParam;
}


// getting fourth argument of url
function routerParams0() {

    global $url;


    $routerParams0 = isset($url[3] ) ? $url[3] : DEFAULT_VALUE;
    return $routerParams0;
}


// router for routing
function router() {

    global $routes;

    $routerController = routerController();


    //    cheking of routerMethod is empty and then unsetting it
//        it is a fix for when there is just / at the end it shows routerMethod as '' which is a bug

    //    seeting controller to index
    if ($routerController == null)
        $routerController = 'index';


    $routerMethod = routerMethod();

// if routerMethod comes as empty, unsetting it
    if (empty($routerMethod))
        unset($routerMethod);


//    if (isset($routerMethod) || !empty($routerMethod)) {
//
//    }

    $routerParams0 = routerParams0();

    // if routerParams0 comes as empty, unsetting it
    if (empty($routerParams0))
        unset($routerParams0);

//    if ($routerMethod == null || !isset($routerMethod)) {

    // check if given url is in one of routes
    if (array_key_exists($routerController, $routes)) {
        require $routes[$routerController];
        exit;
    }

//    }

    if ( $routerController == 'index.php' ) {
        require VIEWS . 'view-home.php'  ;
        die();
    }

//     if not get 404 page
    require VIEWS . 'view-404.php';
    die;
}

 router();
