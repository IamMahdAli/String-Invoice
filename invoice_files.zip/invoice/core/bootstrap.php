<?php

// defining named constants
defined('ROOT') or define('ROOT', dirname(dirname(__FILE__)));

defined('DS') or define('DS', DIRECTORY_SEPARATOR);

defined('ROOT') or define('ROOT',  DS . 'invoice' );

defined('CORE') or define('CORE', ROOT . DS . 'core'. DS );

defined('CONTROLLERS') or define('CONTROLLERS', ROOT . DS . 'controllers'. DS );

defined('VIEWS') or define('VIEWS', ROOT . DS . 'views'. DS );

defined('DB') or define('DB', CORE . 'models'. DS . 'db.php' );

defined('FUNCTIONS') or define('FUNCTIONS', CORE. 'functions' . DS  );

defined('INDEX') or define('INDEX', ROOT . DS . 'public_html'. DS . 'index.php' );

defined('DEFAULT_VALUE') or define('DEFAULT_VALUE', null);

defined('BULMA') or define('BULMA', CORE . 'css' . DS . 'bulma.css' );

defined('PARTIALS') or define('PARTIALS', VIEWS . 'partials' . DS  );

defined('SRC') or define('SRC', DS . 'invoice' . DS . 'src' . DS  );

defined('JS') or define('JS',  SRC . 'js' . DS  );

defined('CSS') or define('CSS', SRC .'css' . DS );

defined('FOOTERJS') or define('FOOTERJS', JS . 'view.footer.js' . DS );

defined('MODELS') or define('MODELS', DS . 'invoice' . DS . 'core' . DS . 'models' . DS );



// requiring files
$requiredFiles = array(FUNCTIONS . 'functions.php', FUNCTIONS . 'helper_functions.php', DB ,
    CORE . 'router.php', CORE . 'routes.php');

foreach ($requiredFiles as $requiredFile) {
    require_once $requiredFile;
}


// default time zone
date_default_timezone_set("Asia/Karachi");

