<?php


//                            start: main functions for functionality


//                             end: main functions for functionality

//                            start: global partials

function get_hover($routerController, $hoverFor) {
    ($routerController === $hoverFor ) ? print'myHover'   : print'' ;

    }

function getHead($currentHeader) {
     switch ($currentHeader) {

        case 'is_new_invoice';

            ?>

            <link href="<?php echo CSS ?>bulma-calendar.min.css" rel="stylesheet">

            <title><?php echo 'Add New Invoice' ?></title>

            <?php break; ?>

        <?php
        case 'is_home';
            ?>
            <title><?php echo 'Invoice' ?></title>

            <?php
            break;

        case 'is_string_inventory';


            ?>
            <title><?php echo 'String Inventory' ?></title>
            <?php
            break;

        case ('is_string_new_record');
            ?>
            <title><?php echo 'New Record' ?></title>

            <?php

            break;

        case 'is_index';
            ?>


            <link rel="stylesheet" href="<?php echo '../src' . DS . 'css' . DS . 'mystyles.css' ?>">
            <!--            <link rel="stylesheet" href="--><?php //echo CSS ?><!--custom.css">-->
            <link rel="stylesheet" href="<?php  echo '../src' . DS . 'css' . DS . 'custom.css' ?>">
            <link rel="stylesheet" href="<?php echo '../src' . DS . 'fonts' . DS . 'css' . DS . 'all.min.css' ?>">


            <title><?php echo 'Invoice' ?></title>

            <?php break; ?>

        <?php
        case ('is_edit_record');

            $title = get_title('edit-record');

            echo 'this is edit record';
            break;

            ?>


        <?php default; ?>

            <title><?php echo 'Invoice' ?></title>

        <?php  }

    }

function get_header($headerFor) {
    require PARTIALS . 'view-global-header.php';
}


function get_header2($routerController) {

    $title = get_title($routerController);
    require PARTIALS . 'view-global-header2.php';
}

function get_print_header($routerController) {

    $title = get_title($routerController);
    require PARTIALS . 'view-global-print-header.php';
}

function get_footer($footerFor) {
    require PARTIALS . 'view-global-footer.php';
}

//                             end: global partials



//                            start: main body parts


function get_new_invoice_body() {
require PARTIALS . 'body' . DS . 'view-body-new-invoice.php';
}


function get_body($whichBody) {
    switch ($whichBody) {

        case('is_new_invoice');
            require PARTIALS . 'body' . DS . 'view-body-new-invoice.php';
            break;
        case ('is_home');

            require  PARTIALS. 'body' . DS . 'view-body-home.php';
            break;

        case ('is_index');

            require  PARTIALS. 'body' . DS . 'view-body-home.php';
            break;

        case ('is_string_inventory');

            require PARTIALS . 'body' . DS . 'view-body-string-inventory.php';
            break;

        case ('is_string_new_record');

            require PARTIALS .  'body' . DS . 'view-body-string-new-record.php';
            break;
//            oops something went wrong :(
            default;
                require PARTIALS . 'body' . DS . 'view-body-404.php';

    }


}
//  upper matches with case


// it require on the base of routerController
function get_body2($bodyFor) {

    require PARTIALS . 'body' . DS . 'view-body-'. $bodyFor . '.php';
    debug_backtrace();

}

// calls footer 2 simply that is more user friendly
function get_footer2($routerController) {
    require PARTIALS  . 'view-global-footer2.php';
}

// calls footer 3 which accepts args from func_get_args
function get_footer3() {

    $routerController = func_get_arg(0);
    $routerMethod = func_get_arg(1);
    $routerParams = func_get_arg(2);

        require PARTIALS  . 'view-global-footer3.php';
}

function get_print_footer() {

    $routerController = func_get_arg(0);
    $routerMethod = func_get_arg(1);
    $routerParams = func_get_arg(2);

    require PARTIALS  . 'view-global-print-footer.php';
}



function footerJsFile($fileFor) {
    ?>
    <script src="<?php echo FOOTERJS ?>js-<?php echo $fileFor ?>.js"></script>
    <?php

}

function jsFile($fileFor) {
        ?>
        <script src="<?php echo JS ?><?php echo $fileFor ?>.js"></script>
        <?php

}

//                             end: main body parts

//                            start: little functions

function get_title($titleFor) {

    return    $titleFor = ucwords(str_replace('-', ' ', $titleFor));

}

function getCss($cssFor) {

    ?>
    <link rel="stylesheet" href="<?php echo CSS . $cssFor ?>.css">
    <?php

}

//                             end: little functions


//                            start: model functions


    function getData($dataFor) {

    $gettingDataFor =  $dataFor;

    switch ($gettingDataFor){
        case ($gettingDataFor );


        break;

        default;

        return null;
    }

    }



//                             end: model functions
