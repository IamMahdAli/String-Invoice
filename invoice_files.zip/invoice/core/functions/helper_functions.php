<?php

// print and break
function pb($toPB) {
    echo '<br><pre>';

    var_dump($toPB);

    echo '<br><pre/>';
}

function dnd($toDND) {
    echo '<br><pre>';

    ECHO 'DND <BR>';
    var_dump($toDND);

    echo '<br><pre/>';
    die();
}


function suppresNotice() {
    error_reporting(E_ALL ^ E_NOTICE);

}
