<?php

$routes = [
    'new-invoice' => CONTROLLERS. 'controller_new_invoice.php',
    'all-invoice' => CONTROLLERS. 'controller_all_invoice.php',
    'view-invoice' => CONTROLLERS. 'controller_view_invoice.php',
    'index.php' => VIEWS . 'view-home.php',
    'index' =>  CONTROLLERS . 'controller_index.php',
    'thread-records' => CONTROLLERS . 'controller_thread_records.php',
    'new-record' => CONTROLLERS . 'controller_new_record.php',
    'edit-record' => CONTROLLERS . 'controller_edit_record.php',
    'get-invoice' => CONTROLLERS . 'controller_get_invoice.php',
    'print-invoice' => CONTROLLERS . 'controller_get_invoice.php'

];
